import os
import random
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

import numpy as np
import pandas as pd
from gensim.corpora import Dictionary
from gensim.models import CoherenceModel, LdaModel
from tqdm import tqdm

from .text_preprocess import (
    get_stopwords,
    preprocess_corpus_from_texts,
    split_sentences_cn,
)


@dataclass
class YearlyLdaArtifacts:
    year: int
    best_k: int
    model_path: str
    dict_path: str
    assignments_path: str


def _set_global_seed(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)


def _ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def _train_lda_with_k(
    corpus_bow: List[List[Tuple[int, int]]],
    dictionary: Dictionary,
    tokens: List[List[str]],
    *,
    k: int,
    seed: int,
    passes: int,
    iterations: int,
    alpha: str = "auto",
    eta: str = "auto",
) -> LdaModel:
    lda = LdaModel(
        corpus=corpus_bow,
        id2word=dictionary,
        num_topics=k,
        random_state=seed,
        passes=passes,
        iterations=iterations,
        alpha=alpha,
        eta=eta,
        update_every=1,
        chunksize=2000,
        eval_every=None,
    )
    return lda


def _compute_cv_coherence(
    lda_model: LdaModel,
    tokens: List[List[str]],
    dictionary: Dictionary,
) -> float:
    coherence_model = CoherenceModel(
        model=lda_model,
        texts=tokens,
        dictionary=dictionary,
        coherence="c_v",
    )
    return float(coherence_model.get_coherence())


def train_yearly_independent_lda(
    df: pd.DataFrame,
    *,
    ticker_col: str = "ticker",
    year_col: str = "year",
    text_col: str = "mda_text",
    years: Optional[Sequence[int]] = None,
    out_dir: str = "outputs/step1/yearly_lda",
    seed: int = 42,
    k_min: int = 10,
    k_max: int = 100,
    k_step: int = 5,
    coherence_sample_frac: float = 1.0,
    passes: int = 5,
    iterations: int = 100,
    stopwords: Iterable[str] | None = None,
    min_sentence_char_len: int = 5,
    min_token_len: int = 2,
    dict_no_below: int = 2,
    dict_no_above: float = 0.5,
    dict_keep_n: Optional[int] = None,
    save_assignments_csv: bool = True,
    verbose: bool = True,
) -> Tuple[pd.DataFrame, Dict[int, int], List[YearlyLdaArtifacts]]:
    """
    Step 1:
    - 每年独立训练 LDA（训练语料=该年所有公司MD&A切句+分词）
    - 在[K_min, K_max]网格上用C_v选择最优K_t
    - 为该年每个句子分配主题ID（argmax topic prob）
    - 保存：模型/dictionary/该年句子主题分配
    """
    if years is None:
        years = sorted(df[year_col].dropna().unique().tolist())
    else:
        years = sorted(list(years))

    _set_global_seed(seed)
    stop_set: Set[str] = get_stopwords(stopwords)

    _ensure_dir(out_dir)

    all_assignments: List[pd.DataFrame] = []
    year_to_best_k: Dict[int, int] = {}
    artifacts: List[YearlyLdaArtifacts] = []

    k_grid = list(range(k_min, k_max + 1, k_step))
    if verbose:
        print(f"[Step1] years={years}, k_grid={k_grid} (C_v)")

    # 对每一年分别训练
    for year in years:
        df_year = df[df[year_col] == year].copy()
        if df_year.empty:
            if verbose:
                print(f"[Step1] year={year} empty -> skip")
            continue

        # 1) 切句 + 预处理
        sentence_records: List[Dict] = []
        all_sentences: List[str] = []
        for _, row in df_year[[ticker_col, text_col, year_col]].iterrows():
            ticker = row[ticker_col]
            text = row[text_col]
            sentences = split_sentences_cn(text)
            # 根据你给的规则：字符长度 >= 5
            for s in sentences:
                if len(s.strip()) >= min_sentence_char_len:
                    sentence_records.append(
                        {
                            "ticker": ticker,
                            "year": year,
                            "sentence_text": s.strip(),
                        }
                    )
                    all_sentences.append(s.strip())

        if len(sentence_records) == 0:
            if verbose:
                print(f"[Step1] year={year} no sentences after filter -> skip")
            continue

        tokens_all = preprocess_corpus_from_texts(
            all_sentences,
            stopwords=stop_set,
            min_char_len=min_sentence_char_len,
            min_token_len=min_token_len,
        )

        valid_idx = [i for i, toks in enumerate(tokens_all) if len(toks) > 0]
        if len(valid_idx) == 0:
            if verbose:
                print(f"[Step1] year={year} no valid tokenized sentences -> skip")
            continue

        # 压缩：只保留有效句子（用于训练与分配）
        tokens = [tokens_all[i] for i in valid_idx]
        sentence_records = [sentence_records[i] for i in valid_idx]
        corpus_texts = tokens  # coherence用

        # 2) 构建字典和BOW
        dictionary = Dictionary(corpus_texts)
        dictionary.filter_extremes(
            no_below=dict_no_below,
            no_above=dict_no_above,
            keep_n=dict_keep_n,
        )
        if len(dictionary) == 0:
            raise ValueError(f"[Step1] year={year} dictionary is empty after filter_extremes.")

        corpus_bow = [dictionary.doc2bow(toks) for toks in corpus_texts]

        # 3) 用C_v挑最优K_t
        # coherence加速：可抽样
        if coherence_sample_frac < 1.0:
            rng = np.random.default_rng(seed + year)
            n = len(corpus_texts)
            m = max(10, int(n * coherence_sample_frac))
            sample_idx = rng.choice(n, size=m, replace=False)
            coh_tokens = [corpus_texts[i] for i in sample_idx]
        else:
            coh_tokens = corpus_texts

        best_k = None
        best_score = -np.inf
        k2score: Dict[int, float] = {}

        if verbose:
            print(f"[Step1] Training year={year} | sentences={len(corpus_texts)} | dict_size={len(dictionary)}")

        for k in k_grid:
            lda_tmp = _train_lda_with_k(
                corpus_bow=corpus_bow,
                dictionary=dictionary,
                tokens=corpus_texts,
                k=k,
                seed=seed,
                passes=passes,
                iterations=iterations,
            )
            # coherence计算使用（可能抽样）tokens；dictionary不变
            score = _compute_cv_coherence(lda_tmp, coh_tokens, dictionary)
            k2score[k] = score
            if verbose:
                print(f"[Step1] year={year} k={k} c_v={score:.4f}")
            if score > best_score or (score == best_score and (best_k is None or k < best_k)):
                best_score = score
                best_k = k

        assert best_k is not None
        year_to_best_k[year] = int(best_k)
        if verbose:
            print(f"[Step1] year={year} best_k={best_k} best_c_v={best_score:.4f}")

        # 4) 用best_k训练最终模型（全量语料）
        lda_final = _train_lda_with_k(
            corpus_bow=corpus_bow,
            dictionary=dictionary,
            tokens=corpus_texts,
            k=best_k,
            seed=seed,
            passes=passes,
            iterations=iterations,
        )

        # 5) 保存模型与dictionary
        year_dir = os.path.join(out_dir, str(year))
        _ensure_dir(year_dir)
        model_path = os.path.join(year_dir, f"lda_{year}.model")
        dict_path = os.path.join(year_dir, f"dict_{year}.dict")
        assignments_path = os.path.join(year_dir, f"assignments_{year}.csv")

        lda_final.save(model_path)
        dictionary.save(dict_path)

        # 6) 为每句做主题分配：argmax(topic_prob)
        topic_ids: List[int] = []
        topic_probs: List[float] = []
        for bow in corpus_bow:
            topics = lda_final.get_document_topics(bow, minimum_probability=0.0)
            if not topics:
                topic_ids.append(-1)
                topic_probs.append(0.0)
                continue
            tid, prob = max(topics, key=lambda x: x[1])
            topic_ids.append(int(tid))
            topic_probs.append(float(prob))

        assignments_df = pd.DataFrame(
            {
                "ticker": [r["ticker"] for r in sentence_records],
                "year": [r["year"] for r in sentence_records],
                "sentence_text": [r["sentence_text"] for r in sentence_records],
                "topic_id": topic_ids,
                "topic_prob": topic_probs,
            }
        )

        if save_assignments_csv:
            assignments_df.to_csv(assignments_path, index=False, encoding="utf-8-sig")

        all_assignments.append(assignments_df)
        artifacts.append(
            YearlyLdaArtifacts(
                year=int(year),
                best_k=int(best_k),
                model_path=model_path,
                dict_path=dict_path,
                assignments_path=assignments_path,
            )
        )

    yearly_assignments_df = pd.concat(all_assignments, ignore_index=True) if all_assignments else pd.DataFrame()

    if verbose and not yearly_assignments_df.empty:
        print(f"[Step1] all years done. assignments rows={len(yearly_assignments_df)}")

    return yearly_assignments_df, year_to_best_k, artifacts


def run_step1(
    df: pd.DataFrame,
    *,
    ticker_col: str = "ticker",
    year_col: str = "year",
    text_col: str = "mda_text",
    years: Optional[Sequence[int]] = None,
    out_dir: str = "outputs/step1/yearly_lda",
    seed: int = 42,
    k_min: int = 10,
    k_max: int = 100,
    k_step: int = 5,
    coherence_sample_frac: float = 1.0,
    passes: int = 5,
    iterations: int = 100,
    stopwords: Iterable[str] | None = None,
    min_sentence_char_len: int = 5,
    min_token_len: int = 2,
    dict_no_below: int = 2,
    dict_no_above: float = 0.5,
    dict_keep_n: Optional[int] = None,
    verbose: bool = True,
) -> Tuple[pd.DataFrame, Dict[int, int], List[YearlyLdaArtifacts]]:
    """对外的 Step1 入口：你只需要传入含 `ticker/year/mda_text` 的 DataFrame。"""
    return train_yearly_independent_lda(
        df,
        ticker_col=ticker_col,
        year_col=year_col,
        text_col=text_col,
        years=years,
        out_dir=out_dir,
        seed=seed,
        k_min=k_min,
        k_max=k_max,
        k_step=k_step,
        coherence_sample_frac=coherence_sample_frac,
        passes=passes,
        iterations=iterations,
        stopwords=stopwords,
        min_sentence_char_len=min_sentence_char_len,
        min_token_len=min_token_len,
        dict_no_below=dict_no_below,
        dict_no_above=dict_no_above,
        dict_keep_n=dict_keep_n,
        verbose=verbose,
    )

