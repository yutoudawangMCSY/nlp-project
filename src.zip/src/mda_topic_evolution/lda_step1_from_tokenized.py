from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from gensim.corpora import Dictionary
from gensim.models import CoherenceModel, LdaModel
from tqdm import tqdm


@dataclass
class TokenizedSentenceMeta:
    ticker: str
    year: int
    sentence_text: str  # tokenized sentence text (e.g. "token1 token2 ...")


def set_seed(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)


def train_lda_single_year_from_tokens(
    *,
    year: int,
    tokens_per_sentence: Sequence[Sequence[str]],
    sentence_metas: Sequence[TokenizedSentenceMeta],
    seed: int = 42,
    out_dir: str,
    k_min: int = 10,
    k_max: int = 100,
    k_step: int = 5,
    coherence_sample_frac: float = 1.0,
    passes: int = 5,
    iterations: int = 100,
    dict_no_below: int = 2,
    dict_no_above: float = 0.5,
    dict_keep_n: Optional[int] = None,
    verbose: bool = True,
) -> Tuple[pd.DataFrame, int]:
    """
    从“已按句分词”的 tokens_per_sentence 直接训练该年的独立 LDA。
    tokens_per_sentence 与 sentence_metas 必须一一对应（长度一致）。
    """
    assert len(tokens_per_sentence) == len(sentence_metas), "tokens_per_sentence 与 sentence_metas 长度不一致"

    set_seed(seed)

    # 过滤空句
    keep_mask = [len(toks) > 0 for toks in tokens_per_sentence]
    tokens = [tokens_per_sentence[i] for i, ok in enumerate(keep_mask) if ok]
    metas = [sentence_metas[i] for i, ok in enumerate(keep_mask) if ok]

    if len(tokens) == 0:
        raise ValueError(f"[Step1] year={year} no tokens after filtering.")

    dictionary = Dictionary(tokens)
    dictionary.filter_extremes(
        no_below=dict_no_below,
        no_above=dict_no_above,
        keep_n=dict_keep_n,
    )
    if len(dictionary) == 0:
        raise ValueError(f"[Step1] year={year} dictionary is empty after filter_extremes.")

    corpus_bow = [dictionary.doc2bow(toks) for toks in tokens]

    # 用 C_v 选择 K_t
    k_grid = list(range(k_min, k_max + 1, k_step))

    if coherence_sample_frac < 1.0:
        rng = np.random.default_rng(seed + year)
        n = len(tokens)
        m = max(10, int(n * coherence_sample_frac))
        sample_idx = rng.choice(n, size=m, replace=False)
        coh_tokens = [tokens[i] for i in sample_idx]
    else:
        coh_tokens = tokens

    best_k: Optional[int] = None
    best_score = -np.inf
    k2score: Dict[int, float] = {}

    if verbose:
        print(f"[Step1] year={year} sentences={len(tokens)} dict_size={len(dictionary)} k_grid={k_grid}")

    for k in k_grid:
        lda_tmp = LdaModel(
            corpus=corpus_bow,
            id2word=dictionary,
            num_topics=k,
            random_state=seed,
            passes=passes,
            iterations=iterations,
            alpha="auto",
            eta="auto",
            update_every=1,
            chunksize=2000,
            eval_every=None,
        )
        coherence_model = CoherenceModel(
            model=lda_tmp,
            texts=coh_tokens,
            dictionary=dictionary,
            coherence="c_v",
        )
        score = float(coherence_model.get_coherence())
        k2score[k] = score
        if verbose:
            print(f"[Step1] year={year} k={k} c_v={score:.4f}")

        if score > best_score or (score == best_score and (best_k is None or k < best_k)):
            best_score = score
            best_k = k

    assert best_k is not None

    if verbose:
        print(f"[Step1] year={year} best_k={best_k} best_c_v={best_score:.4f}")

    # 训练最终模型（全量）
    lda_final = LdaModel(
        corpus=corpus_bow,
        id2word=dictionary,
        num_topics=best_k,
        random_state=seed,
        passes=passes,
        iterations=iterations,
        alpha="auto",
        eta="auto",
        update_every=1,
        chunksize=2000,
        eval_every=None,
    )

    # 保存
    import os

    year_dir = os.path.join(out_dir, str(year))
    os.makedirs(year_dir, exist_ok=True)
    model_path = os.path.join(year_dir, f"lda_{year}.model")
    dict_path = os.path.join(year_dir, f"dict_{year}.dict")
    assignments_path = os.path.join(year_dir, f"assignments_{year}.csv")

    lda_final.save(model_path)
    dictionary.save(dict_path)

    # 分配主题：argmax topic prob
    topic_ids: List[int] = []
    topic_probs: List[float] = []
    for bow in corpus_bow:
        topics = lda_final.get_document_topics(bow, minimum_probability=0.0)
        if not topics:
            topic_ids.append(-1)
            topic_probs.append(0.0)
            continue
        tid, prob = max(topics, key=lambda x: x[1])
        topic_ids.append(int(tid))
        topic_probs.append(float(prob))

    assignments_df = pd.DataFrame(
        {
            "ticker": [m.ticker for m in metas],
            "year": [m.year for m in metas],
            "sentence_text": [m.sentence_text for m in metas],
            "topic_id": topic_ids,
            "topic_prob": topic_probs,
        }
    )
    assignments_df.to_csv(assignments_path, index=False, encoding="utf-8-sig")

    return assignments_df, int(best_k)

