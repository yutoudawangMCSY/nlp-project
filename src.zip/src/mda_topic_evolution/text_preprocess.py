import re
from typing import Iterable, List, Sequence, Set

import jieba


_SENT_SPLIT_RE = re.compile(r"[。！？；]")

# 分词前：去掉数字（含全角）及百分号类等符号，避免数值噪声进入主题词表
_DIGITS_RE = re.compile(r"[0-9０-９]+")
_PCT_LIKE_RE = re.compile(r"[%％‰‱]")
_WS_RE = re.compile(r"\s+")


def strip_digits_and_pct_symbols(text: str) -> str:
    """去除 ASCII/全角连续数字，以及 %、％、‰、‱ 等符号，并压缩空白。"""
    if not text:
        return ""
    s = _DIGITS_RE.sub(" ", text)
    s = _PCT_LIKE_RE.sub(" ", s)
    return _WS_RE.sub(" ", s).strip()


DEFAULT_STOPWORDS: Set[str] = {
    # 常见功能词（占位版，可在后续替换为你自己的停用词表）
    "的",
    "了",
    "和",
    "及",
    "与",
    "或",
    "在",
    "对",
    "从",
    "而",
    "为",
    "到",
    "并",
    "但",
    "其",
    "这",
    "那",
    "一个",
    "没有",
    "我们",
    "你们",
    "他们",
    "公司",
    "报告",
    "以及",
    "以及",
    "同时",
    "为此",
    "因此",
    "同时",
}


def split_sentences_cn(text: str) -> List[str]:
    """按中文标点切句；返回去首尾空白后的句子列表。"""
    if text is None:
        return []
    text = str(text).replace("\r", "\n")
    # 先用中文标点切，再按换行做一次兜底切分
    parts = _SENT_SPLIT_RE.split(text)
    sentences: List[str] = []
    for p in parts:
        for s in str(p).split("\n"):
            s = s.strip()
            if s:
                sentences.append(s)
    return sentences


def preprocess_sentence_tokens(
    sentence: str,
    *,
    stopwords: Set[str],
    min_char_len: int = 5,
    min_token_len: int = 2,
) -> List[str]:
    """对单句做切词、去停用词，并过滤短 token。分词前会去掉数字与 % 类等符号。"""
    if sentence is None:
        return []
    sentence = strip_digits_and_pct_symbols(sentence.strip())
    if len(sentence) < min_char_len:
        return []
    tokens = jieba.lcut(sentence, HMM=True)
    kept: List[str] = []
    for tok in tokens:
        tok = tok.strip()
        if not tok:
            continue
        if tok in stopwords:
            continue
        if len(tok) < min_token_len:
            continue
        kept.append(tok)
    return kept


def preprocess_corpus_from_texts(
    sentences: Sequence[str],
    *,
    stopwords: Set[str],
    min_char_len: int = 5,
    min_token_len: int = 2,
) -> List[List[str]]:
    """对句子序列批量做分词预处理。"""
    processed: List[List[str]] = []
    for s in sentences:
        toks = preprocess_sentence_tokens(
            s,
            stopwords=stopwords,
            min_char_len=min_char_len,
            min_token_len=min_token_len,
        )
        if toks:
            processed.append(toks)
        else:
            processed.append([])
    return processed


def get_stopwords(stopwords: Iterable[str] | None) -> Set[str]:
    """合并/覆盖停用词集合。"""
    if stopwords is None:
        return set(DEFAULT_STOPWORDS)
    return set(DEFAULT_STOPWORDS).union({w.strip() for w in stopwords if str(w).strip()})

