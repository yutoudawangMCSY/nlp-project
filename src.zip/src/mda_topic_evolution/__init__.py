"""
用于“主题演化研究”的逐年独立 LDA（Step 1）。
"""

from .lda_step1 import train_yearly_independent_lda, run_step1

__all__ = ["train_yearly_independent_lda", "run_step1"]
